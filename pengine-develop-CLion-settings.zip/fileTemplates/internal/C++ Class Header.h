#parse("C File Header.h")
#[[#pragma]]# once

${NAMESPACES_OPEN}

class ${NAME} {

};

${NAMESPACES_CLOSE}

